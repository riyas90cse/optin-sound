### MailChimp (API v3) Subscribe Form with PHP, jQuery and AJAX

MailChimp provides a good tool to generate your custom sign up form which will serve most requirements well. Some users however, want a fully custom form or integrate it with existing template they already own.

This is an update from [previous version](https://github.com/sunarlim/mailchimp-subscribe) which was still using MailChimp API v1.

Tools/Credits:
* [jQuery](http://jquery.com/)
* [jQuery Validation](http://jqueryvalidation.org/)
* [MailChimp API v3 PHP Wrapper](https://github.com/drewm/mailchimp-api)
