<?php    
require __DIR__.'/API_SG.php';

$membreid       = 123456;
$codeactivation = 'xxxxx';


echo '<pre>';
//démarrage de l'api
$sgApi = new API_SG($membreid, $codeactivation);

$sgApi
    ->set('listeid', 123456)
    ->set('detail', true);

$call = $sgApi->call('get_list');

//définition des variables


//appel
try{
    $call = $sgApi->call('get_mail');

    //retour
    print_r(
        json_decode($call)
    );
    exit();

    
} catch (Exception $e){
//    SG Non joignable.
    die($e);
}
