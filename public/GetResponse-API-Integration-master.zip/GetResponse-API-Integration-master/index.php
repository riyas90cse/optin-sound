<?php 
//Link to purl_include.php from your Purlem landing page (index.php) file
include ("path/to/getresponse/purl_include.php");
?>